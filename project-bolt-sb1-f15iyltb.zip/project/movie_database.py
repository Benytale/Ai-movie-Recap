import requests
import random
from datetime import datetime, timedelta

class MovieDatabase:
    """Handle movie selection and metadata"""
    
    def __init__(self, tmdb_api_key=None):
        self.tmdb_api_key = tmdb_api_key
        self.base_url = "https://api.themoviedb.org/3"
        self.used_movies = set()
        
        # Fallback popular movies list
        self.popular_movies = [
            {"title": "The Shawshank Redemption", "year": 1994, "genre": "Drama"},
            {"title": "The Godfather", "year": 1972, "genre": "Crime"},
            {"title": "The Dark Knight", "year": 2008, "genre": "Action"},
            {"title": "Pulp Fiction", "year": 1994, "genre": "Crime"},
            {"title": "The Lord of the Rings: The Return of the King", "year": 2003, "genre": "Fantasy"},
            {"title": "Forrest Gump", "year": 1994, "genre": "Drama"},
            {"title": "Inception", "year": 2010, "genre": "Sci-Fi"},
            {"title": "The Matrix", "year": 1999, "genre": "Sci-Fi"},
            {"title": "Goodfellas", "year": 1990, "genre": "Crime"},
            {"title": "The Silence of the Lambs", "year": 1991, "genre": "Thriller"},
            {"title": "Saving Private Ryan", "year": 1998, "genre": "War"},
            {"title": "Schindler's List", "year": 1993, "genre": "Drama"},
            {"title": "Terminator 2: Judgment Day", "year": 1991, "genre": "Action"},
            {"title": "Back to the Future", "year": 1985, "genre": "Adventure"},
            {"title": "Alien", "year": 1979, "genre": "Horror"},
            {"title": "The Departed", "year": 2006, "genre": "Crime"},
            {"title": "Gladiator", "year": 2000, "genre": "Action"},
            {"title": "Titanic", "year": 1997, "genre": "Romance"},
            {"title": "The Green Mile", "year": 1999, "genre": "Drama"},
            {"title": "Interstellar", "year": 2014, "genre": "Sci-Fi"},
            {"title": "Parasite", "year": 2019, "genre": "Thriller"},
            {"title": "Avengers: Endgame", "year": 2019, "genre": "Action"},
            {"title": "Joker", "year": 2019, "genre": "Drama"},
            {"title": "Once Upon a Time in Hollywood", "year": 2019, "genre": "Drama"},
            {"title": "1917", "year": 2019, "genre": "War"},
            {"title": "Jaws", "year": 1975, "genre": "Thriller"},
            {"title": "E.T. the Extra-Terrestrial", "year": 1982, "genre": "Family"},
            {"title": "Casablanca", "year": 1942, "genre": "Romance"},
            {"title": "The Wizard of Oz", "year": 1939, "genre": "Fantasy"},
            {"title": "Lawrence of Arabia", "year": 1962, "genre": "Adventure"}
        ]
    
    def get_trending_movies(self):
        """Get trending movies from TMDB API"""
        if not self.tmdb_api_key:
            return []
        
        try:
            url = f"{self.base_url}/trending/movie/week"
            params = {
                "api_key": self.tmdb_api_key,
                "language": "en-US"
            }
            
            response = requests.get(url, params=params)
            response.raise_for_status()
            
            data = response.json()
            movies = []
            
            for movie in data.get("results", []):
                movies.append({
                    "title": movie["title"],
                    "year": int(movie["release_date"][:4]) if movie.get("release_date") else None,
                    "genre": "Unknown",  # Would need additional API call for genres
                    "popularity": movie.get("popularity", 0),
                    "vote_average": movie.get("vote_average", 0)
                })
            
            return movies
        except Exception as e:
            print(f"Error fetching trending movies: {e}")
            return []
    
    def get_popular_movies(self):
        """Get popular movies from TMDB API"""
        if not self.tmdb_api_key:
            return []
        
        try:
            url = f"{self.base_url}/movie/popular"
            params = {
                "api_key": self.tmdb_api_key,
                "language": "en-US",
                "page": 1
            }
            
            response = requests.get(url, params=params)
            response.raise_for_status()
            
            data = response.json()
            movies = []
            
            for movie in data.get("results", []):
                movies.append({
                    "title": movie["title"],
                    "year": int(movie["release_date"][:4]) if movie.get("release_date") else None,
                    "genre": "Unknown",
                    "popularity": movie.get("popularity", 0),
                    "vote_average": movie.get("vote_average", 0)
                })
            
            return movies
        except Exception as e:
            print(f"Error fetching popular movies: {e}")
            return []
    
    def select_movie(self):
        """Select a movie for recap generation"""
        # Try to get movies from TMDB first
        movies = self.get_trending_movies()
        if not movies:
            movies = self.get_popular_movies()
        
        # Fallback to hardcoded list
        if not movies:
            movies = self.popular_movies
        
        # Filter out already used movies
        available_movies = [m for m in movies if m["title"] not in self.used_movies]
        
        # Reset if all movies have been used
        if not available_movies:
            self.used_movies.clear()
            available_movies = movies
        
        # Select movie
        if available_movies:
            selected_movie = random.choice(available_movies)
            self.used_movies.add(selected_movie["title"])
            return selected_movie
        
        return None
    
    def get_movie_info(self, title):
        """Get detailed movie information"""
        if not self.tmdb_api_key:
            return None
        
        try:
            # Search for the movie
            url = f"{self.base_url}/search/movie"
            params = {
                "api_key": self.tmdb_api_key,
                "query": title,
                "language": "en-US"
            }
            
            response = requests.get(url, params=params)
            response.raise_for_status()
            
            data = response.json()
            results = data.get("results", [])
            
            if results:
                movie = results[0]  # Take the first result
                return {
                    "title": movie["title"],
                    "overview": movie.get("overview", ""),
                    "release_date": movie.get("release_date", ""),
                    "vote_average": movie.get("vote_average", 0),
                    "popularity": movie.get("popularity", 0),
                    "poster_path": movie.get("poster_path", ""),
                    "backdrop_path": movie.get("backdrop_path", "")
                }
            
            return None
        except Exception as e:
            print(f"Error fetching movie info for {title}: {e}")
            return None
    
    def get_movie_credits(self, movie_id):
        """Get movie cast and crew"""
        if not self.tmdb_api_key:
            return None
        
        try:
            url = f"{self.base_url}/movie/{movie_id}/credits"
            params = {"api_key": self.tmdb_api_key}
            
            response = requests.get(url, params=params)
            response.raise_for_status()
            
            return response.json()
        except Exception as e:
            print(f"Error fetching movie credits: {e}")
            return None