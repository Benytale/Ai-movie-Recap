import os
from pathlib import Path

class Config:
    # Flask configuration
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'your-secret-key-here'
    DEBUG = os.environ.get('FLASK_DEBUG', 'False').lower() == 'true'
    
    # API Keys
    OPENAI_API_KEY = os.environ.get('OPENAI_API_KEY')
    JSON2VIDEO_API_KEY = os.environ.get('JSON2VIDEO_API_KEY')
    
    # File paths
    BASE_DIR = Path(__file__).parent
    STATIC_DIR = BASE_DIR / 'static'
    VIDEOS_DIR = STATIC_DIR / 'videos'
    METADATA_DIR = STATIC_DIR / 'metadata'
    
    # Video generation settings
    VIDEO_RESOLUTION = "1920x1080"
    VIDEO_QUALITY = "high"
    SCRIPT_LENGTH = 800  # words
    VIDEO_DURATION = 300  # seconds (5 minutes)
    
    # Scheduling
    GENERATION_INTERVAL = 60  # minutes
    
    # Movie database
    USE_TMDB = os.environ.get('USE_TMDB', 'False').lower() == 'true'
    TMDB_API_KEY = os.environ.get('TMDB_API_KEY')
    
    @classmethod
    def init_app(cls, app):
        # Create directories
        cls.VIDEOS_DIR.mkdir(parents=True, exist_ok=True)
        cls.METADATA_DIR.mkdir(parents=True, exist_ok=True)

class DevelopmentConfig(Config):
    DEBUG = True
    GENERATION_INTERVAL = 5  # minutes for testing

class ProductionConfig(Config):
    DEBUG = False
    
    @classmethod
    def init_app(cls, app):
        Config.init_app(app)
        
        # Log to stderr
        import logging
        from logging import StreamHandler
        file_handler = StreamHandler()
        file_handler.setLevel(logging.INFO)
        app.logger.addHandler(file_handler)

config = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
    'default': DevelopmentConfig
}