# AI Movie Recap Generator

A fully automated system that generates movie recap videos every hour using AI technology. The system uses GPT-4 to create engaging scripts and JSON2Video API to produce high-quality narrated videos with captions and music.

## Features

- **Automated Generation**: Creates new movie recap videos every hour (24/7)
- **AI-Powered Scripts**: Uses GPT-4 to generate engaging 5-minute movie recap scripts
- **Professional Videos**: JSON2Video API creates videos with voiceover, captions, and background music
- **Web Interface**: Beautiful web app to view and download all generated videos
- **SEO Optimization**: Generates metadata and hashtags for each video
- **Cloud Deployment**: Ready for deployment on Render.com, Replit, or PythonAnywhere

## Tech Stack

- **Backend**: Python 3.11+ with Flask
- **AI**: OpenAI GPT-4 API
- **Video Generation**: JSON2Video API
- **Frontend**: Bootstrap 5 with responsive design
- **Deployment**: Gunicorn, Docker-ready
- **Scheduling**: Built-in cron-like scheduler

## Quick Start

### 1. Clone and Setup

```bash
git clone <repository-url>
cd ai-movie-recap-generator
pip install -r requirements.txt
```

### 2. Environment Configuration

Copy `.env.example` to `.env` and configure:

```env
OPENAI_API_KEY=your_openai_api_key_here
JSON2VIDEO_API_KEY=your_json2video_api_key_here
FLASK_ENV=production
```

### 3. Get API Keys

**OpenAI API Key:**
1. Visit [OpenAI Platform](https://platform.openai.com/api-keys)
2. Create account and generate API key
3. Ensure you have GPT-4 access

**JSON2Video API Key:**
1. Visit [JSON2Video](https://json2video.com/)
2. Sign up for an account
3. Get your API key from the dashboard

### 4. Local Development

```bash
python app.py
```

Visit `http://localhost:5000` to see the web interface.

## Deployment

### Render.com (Recommended)

1. Fork this repository
2. Connect to Render.com
3. Create a new Web Service
4. Use the provided `render.yaml` configuration
5. Set environment variables in Render dashboard
6. Deploy!

### Replit

1. Import repository to Replit
2. Install dependencies: `pip install -r requirements.txt`
3. Set environment variables in Secrets
4. Run with: `python app.py`

### PythonAnywhere

1. Upload code to PythonAnywhere
2. Create virtual environment and install dependencies
3. Configure WSGI file to point to `app.py`
4. Set environment variables in Web tab
5. Reload web app

## How It Works

### 1. Movie Selection
- Randomly selects from a curated list of popular movies
- Tracks used movies to avoid repetition
- Resets list when all movies have been used

### 2. Script Generation
- Uses GPT-4 to create engaging 5-minute recap scripts
- Includes plot summary, character arcs, and key scenes
- Optimized for narration and viewer engagement

### 3. Video Creation
- JSON2Video API creates professional videos
- Adds voiceover using high-quality text-to-speech
- Includes captions for accessibility
- Background music enhances the viewing experience

### 4. File Management
- Videos saved with timestamped filenames
- Metadata generated for SEO optimization
- Automatic cleanup of old files (configurable)

## File Structure

```
ai-movie-recap-generator/
├── app.py                 # Main Flask application
├── config.py             # Configuration settings
├── utils.py              # Utility functions
├── movie_database.py     # Movie selection logic
├── requirements.txt      # Python dependencies
├── render.yaml          # Render.com deployment config
├── Procfile             # Process configuration
├── .env.example         # Environment variables template
├── templates/
│   ├── index.html       # Main web interface
│   └── base.html        # Base template
├── static/
│   ├── videos/          # Generated video files
│   ├── metadata/        # SEO metadata files
│   └── archives/        # Daily ZIP archives
└── README.md            # This file
```

## API Endpoints

- `GET /` - Main web interface
- `GET /api/videos` - JSON list of all videos
- `GET /video/<filename>` - Stream video file
- `GET /download/<filename>` - Download video file
- `POST /generate-now` - Manually trigger generation

## Configuration Options

Edit `config.py` to customize:

- Video resolution and quality
- Generation interval (default: 60 minutes)
- Script length and video duration
- File storage locations
- Movie database settings

## Monitoring and Maintenance

### Logs
- Application logs show generation progress
- Error handling for API failures
- Video validation and retry logic

### Storage Management
- Automatic cleanup of old files
- Daily ZIP archives for easy backup
- Configurable storage limits

### Performance
- Background processing doesn't block web interface
- Efficient video streaming
- Responsive design for all devices

## Troubleshooting

### Common Issues

**Videos not generating:**
- Check API keys are correctly set
- Verify API quotas and billing
- Check logs for specific error messages

**Slow video generation:**
- JSON2Video API can take 5-15 minutes per video
- This is normal - the system will retry on failure

**Storage space:**
- Videos are ~50-100MB each
- Configure automatic cleanup in `utils.py`
- Use external storage for large deployments

### Getting Help

1. Check the logs for error messages
2. Verify all environment variables are set
3. Test API keys independently
4. Check API service status pages

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## Support

For issues and questions:
- Check the troubleshooting section
- Review the logs for error details
- Open an issue on GitHub with full error details