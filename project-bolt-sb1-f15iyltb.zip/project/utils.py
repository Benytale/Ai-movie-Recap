import os
import json
import hashlib
from datetime import datetime
from pathlib import Path
import zipfile

def create_daily_archive(videos_dir, date_str=None):
    """Create a ZIP archive of all videos from a specific day"""
    if date_str is None:
        date_str = datetime.now().strftime("%Y-%m-%d")
    
    archive_name = f"movie_recaps_{date_str}.zip"
    archive_path = Path(videos_dir).parent / "archives" / archive_name
    archive_path.parent.mkdir(exist_ok=True)
    
    with zipfile.ZipFile(archive_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for video_file in Path(videos_dir).glob(f"{date_str}*.mp4"):
            zipf.write(video_file, video_file.name)
    
    return archive_path

def get_file_hash(filepath):
    """Get SHA256 hash of a file"""
    hash_sha256 = hashlib.sha256()
    with open(filepath, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            hash_sha256.update(chunk)
    return hash_sha256.hexdigest()

def validate_video_file(filepath):
    """Validate that a video file is not corrupted"""
    try:
        file_size = os.path.getsize(filepath)
        if file_size < 1024 * 1024:  # Less than 1MB
            return False
        
        # Additional validation could include ffprobe
        return True
    except:
        return False

def clean_old_files(directory, days_old=30):
    """Remove files older than specified days"""
    cutoff_time = datetime.now().timestamp() - (days_old * 24 * 60 * 60)
    
    for file_path in Path(directory).glob("*"):
        if file_path.stat().st_mtime < cutoff_time:
            file_path.unlink()
            print(f"Removed old file: {file_path}")

def format_file_size(size_bytes):
    """Format file size in human readable format"""
    if size_bytes == 0:
        return "0B"
    
    size_names = ["B", "KB", "MB", "GB", "TB"]
    i = 0
    while size_bytes >= 1024 and i < len(size_names) - 1:
        size_bytes /= 1024
        i += 1
    
    return f"{size_bytes:.1f}{size_names[i]}"

def generate_video_metadata(video_path, movie_title, script):
    """Generate comprehensive metadata for a video"""
    metadata = {
        "title": movie_title,
        "filename": video_path.name,
        "generated_at": datetime.now().isoformat(),
        "file_size": video_path.stat().st_size,
        "file_hash": get_file_hash(video_path),
        "script_length": len(script.split()),
        "seo_title": f"{movie_title} - Complete Movie Recap & Summary",
        "description": f"Watch this AI-generated recap of {movie_title}. Get the complete story with all major plot points, character development, and key scenes explained in 5 minutes.",
        "hashtags": ["#MovieRecap", "#AIGenerated", "#MovieSummary", f"#{movie_title.replace(' ', '')}", "#FilmReview"],
        "tags": ["movie recap", "film summary", "AI generated", movie_title.lower(), "spoiler review"]
    }
    
    return metadata

class VideoStats:
    """Track video generation statistics"""
    def __init__(self, stats_file="video_stats.json"):
        self.stats_file = Path(stats_file)
        self.stats = self.load_stats()
    
    def load_stats(self):
        """Load existing stats or create new"""
        if self.stats_file.exists():
            with open(self.stats_file, 'r') as f:
                return json.load(f)
        return {
            "total_videos": 0,
            "total_size_mb": 0,
            "generation_errors": 0,
            "average_generation_time": 0,
            "last_generation": None,
            "movies_used": []
        }
    
    def save_stats(self):
        """Save stats to file"""
        with open(self.stats_file, 'w') as f:
            json.dump(self.stats, f, indent=2)
    
    def add_video(self, movie_title, file_size, generation_time):
        """Add a new video to stats"""
        self.stats["total_videos"] += 1
        self.stats["total_size_mb"] += file_size / (1024 * 1024)
        self.stats["movies_used"].append(movie_title)
        self.stats["last_generation"] = datetime.now().isoformat()
        
        # Update average generation time
        current_avg = self.stats["average_generation_time"]
        new_avg = (current_avg * (self.stats["total_videos"] - 1) + generation_time) / self.stats["total_videos"]
        self.stats["average_generation_time"] = new_avg
        
        self.save_stats()
    
    def add_error(self):
        """Record a generation error"""
        self.stats["generation_errors"] += 1
        self.save_stats()
    
    def get_summary(self):
        """Get summary statistics"""
        return {
            "total_videos": self.stats["total_videos"],
            "total_size_gb": round(self.stats["total_size_mb"] / 1024, 2),
            "success_rate": round((self.stats["total_videos"] / (self.stats["total_videos"] + self.stats["generation_errors"])) * 100, 1) if self.stats["total_videos"] > 0 else 0,
            "avg_generation_time_minutes": round(self.stats["average_generation_time"] / 60, 1),
            "last_generation": self.stats["last_generation"]
        }