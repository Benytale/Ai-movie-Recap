import os
import json
import time
import threading
import schedule
import requests
from datetime import datetime
from flask import Flask, render_template, send_file, jsonify
from werkzeug.utils import secure_filename
import openai
from pathlib import Path
import zipfile
import random

app = Flask(__name__)

# Configuration
VIDEOS_DIR = Path("static/videos")
METADATA_DIR = Path("static/metadata")
VIDEOS_DIR.mkdir(parents=True, exist_ok=True)
METADATA_DIR.mkdir(parents=True, exist_ok=True)

# API Keys from environment variables
OPENAI_API_KEY = os.getenv('OPENAI_API_KEY')
JSON2VIDEO_API_KEY = os.getenv('JSON2VIDEO_API_KEY')

# Initialize OpenAI
openai.api_key = OPENAI_API_KEY

# Movie database - in production, you'd use a real movie API
POPULAR_MOVIES = [
    "The Shawshank Redemption", "The Godfather", "The Dark Knight", "Pulp Fiction",
    "The Lord of the Rings: The Return of the King", "Forrest Gump", "Inception",
    "The Matrix", "Goodfellas", "The Silence of the Lambs", "Saving Private Ryan",
    "Schindler's List", "Terminator 2: Judgment Day", "Back to the Future",
    "Alien", "The Departed", "Gladiator", "Titanic", "The Green Mile",
    "Interstellar", "Parasite", "Avengers: Endgame", "Joker", "Once Upon a Time in Hollywood"
]

used_movies = set()

class MovieRecapGenerator:
    def __init__(self):
        self.running = False
    
    def get_unused_movie(self):
        """Get a random movie that hasn't been used yet"""
        available_movies = [movie for movie in POPULAR_MOVIES if movie not in used_movies]
        if not available_movies:
            # Reset if all movies have been used
            used_movies.clear()
            available_movies = POPULAR_MOVIES
        
        movie = random.choice(available_movies)
        used_movies.add(movie)
        return movie
    
    def generate_script(self, movie_title):
        """Generate a movie recap script using GPT-4"""
        try:
            prompt = f"""
            Create a compelling 5-minute YouTube-style movie recap script for "{movie_title}". 
            Include:
            - Engaging hook in the first 10 seconds
            - Complete plot summary with major spoilers
            - Key character arcs and memorable scenes
            - Emotional moments and plot twists
            - Satisfying conclusion
            
            Write in an engaging, conversational tone perfect for narration.
            Target length: 700-800 words for 5-minute narration.
            """
            
            response = openai.ChatCompletion.create(
                model="gpt-4",
                messages=[{"role": "user", "content": prompt}],
                max_tokens=1000,
                temperature=0.7
            )
            
            return response.choices[0].message.content.strip()
        except Exception as e:
            print(f"Error generating script: {e}")
            return None
    
    def create_video_with_json2video(self, script, movie_title):
        """Create video using JSON2Video API"""
        try:
            video_config = {
                "resolution": "1920x1080",
                "quality": "high",
                "movie": [
                    {
                        "type": "scene",
                        "duration": 300,  # 5 minutes
                        "elements": [
                            {
                                "type": "text",
                                "text": f"{movie_title} - Movie Recap",
                                "style": {
                                    "font-family": "Arial",
                                    "font-size": 48,
                                    "color": "#FFFFFF",
                                    "background-color": "#000000"
                                },
                                "position": {"x": 50, "y": 50}
                            },
                            {
                                "type": "voiceover",
                                "text": script,
                                "voice": "matthew",  # Professional male voice
                                "speed": 1.0
                            },
                            {
                                "type": "captions",
                                "text": script,
                                "style": {
                                    "font-size": 24,
                                    "color": "#FFFFFF",
                                    "background-color": "rgba(0,0,0,0.7)"
                                }
                            },
                            {
                                "type": "background_music",
                                "track": "corporate_upbeat",
                                "volume": 0.3
                            }
                        ]
                    }
                ]
            }
            
            headers = {
                "Authorization": f"Bearer {JSON2VIDEO_API_KEY}",
                "Content-Type": "application/json"
            }
            
            # Create video
            response = requests.post(
                "https://api.json2video.com/v1/movies",
                headers=headers,
                json=video_config
            )
            
            if response.status_code == 201:
                movie_data = response.json()
                movie_id = movie_data["id"]
                
                # Poll for completion
                while True:
                    status_response = requests.get(
                        f"https://api.json2video.com/v1/movies/{movie_id}",
                        headers=headers
                    )
                    
                    if status_response.status_code == 200:
                        status_data = status_response.json()
                        if status_data["status"] == "completed":
                            return status_data["url"]
                        elif status_data["status"] == "failed":
                            print(f"Video generation failed: {status_data.get('error', 'Unknown error')}")
                            return None
                    
                    time.sleep(30)  # Wait 30 seconds before checking again
            
            return None
            
        except Exception as e:
            print(f"Error creating video: {e}")
            return None
    
    def download_video(self, video_url, movie_title):
        """Download the generated video"""
        try:
            timestamp = datetime.now().strftime("%Y-%m-%d_%H")
            safe_title = secure_filename(movie_title.replace(" ", "-"))
            filename = f"{timestamp}-{safe_title}.mp4"
            filepath = VIDEOS_DIR / filename
            
            response = requests.get(video_url, stream=True)
            response.raise_for_status()
            
            with open(filepath, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    f.write(chunk)
            
            return filename
            
        except Exception as e:
            print(f"Error downloading video: {e}")
            return None
    
    def generate_metadata(self, movie_title, script, filename):
        """Generate SEO metadata for the video"""
        try:
            metadata_prompt = f"""
            Create SEO-friendly metadata for a YouTube video recap of "{movie_title}".
            
            Generate:
            1. Catchy title (under 60 characters)
            2. Description (150-200 words)
            3. 10 relevant hashtags
            4. Tags (comma-separated)
            
            Script summary: {script[:200]}...
            """
            
            response = openai.ChatCompletion.create(
                model="gpt-4",
                messages=[{"role": "user", "content": metadata_prompt}],
                max_tokens=500,
                temperature=0.7
            )
            
            metadata_content = response.choices[0].message.content.strip()
            
            timestamp = datetime.now().strftime("%Y-%m-%d")
            metadata_filename = f"{timestamp}-{secure_filename(movie_title)}.txt"
            metadata_path = METADATA_DIR / metadata_filename
            
            with open(metadata_path, 'w', encoding='utf-8') as f:
                f.write(f"Movie: {movie_title}\n")
                f.write(f"Video File: {filename}\n")
                f.write(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
                f.write(f"\n{metadata_content}\n")
            
            return metadata_filename
            
        except Exception as e:
            print(f"Error generating metadata: {e}")
            return None
    
    def generate_recap(self):
        """Main function to generate a complete movie recap"""
        try:
            print(f"Starting recap generation at {datetime.now()}")
            
            # Get movie title
            movie_title = self.get_unused_movie()
            print(f"Selected movie: {movie_title}")
            
            # Generate script
            script = self.generate_script(movie_title)
            if not script:
                print("Failed to generate script")
                return
            
            print("Script generated successfully")
            
            # Create video
            video_url = self.create_video_with_json2video(script, movie_title)
            if not video_url:
                print("Failed to create video")
                return
            
            print("Video created successfully")
            
            # Download video
            filename = self.download_video(video_url, movie_title)
            if not filename:
                print("Failed to download video")
                return
            
            print(f"Video downloaded: {filename}")
            
            # Generate metadata
            metadata_filename = self.generate_metadata(movie_title, script, filename)
            if metadata_filename:
                print(f"Metadata generated: {metadata_filename}")
            
            print(f"Recap generation completed successfully: {filename}")
            
        except Exception as e:
            print(f"Error in recap generation: {e}")

# Initialize the generator
recap_generator = MovieRecapGenerator()

def run_scheduler():
    """Run the background scheduler"""
    while True:
        schedule.run_pending()
        time.sleep(60)

# Schedule the recap generation every hour
schedule.every().hour.do(recap_generator.generate_recap)

# Start the scheduler in a background thread
scheduler_thread = threading.Thread(target=run_scheduler, daemon=True)
scheduler_thread.start()

@app.route('/')
def home():
    """Main page showing all videos"""
    try:
        video_files = []
        for video_file in VIDEOS_DIR.glob("*.mp4"):
            video_info = {
                'filename': video_file.name,
                'title': video_file.stem.split('-', 2)[-1].replace('-', ' '),
                'timestamp': video_file.stat().st_mtime,
                'size': video_file.stat().st_size
            }
            video_files.append(video_info)
        
        # Sort by timestamp (newest first)
        video_files.sort(key=lambda x: x['timestamp'], reverse=True)
        
        return render_template('index.html', videos=video_files)
    except Exception as e:
        print(f"Error loading videos: {e}")
        return render_template('index.html', videos=[])

@app.route('/video/<filename>')
def serve_video(filename):
    """Serve video files"""
    try:
        return send_file(VIDEOS_DIR / filename, as_attachment=False)
    except Exception as e:
        print(f"Error serving video: {e}")
        return "Video not found", 404

@app.route('/download/<filename>')
def download_video(filename):
    """Download video files"""
    try:
        return send_file(VIDEOS_DIR / filename, as_attachment=True)
    except Exception as e:
        print(f"Error downloading video: {e}")
        return "Video not found", 404

@app.route('/api/videos')
def api_videos():
    """API endpoint for video list"""
    try:
        video_files = []
        for video_file in VIDEOS_DIR.glob("*.mp4"):
            video_info = {
                'filename': video_file.name,
                'title': video_file.stem.split('-', 2)[-1].replace('-', ' '),
                'timestamp': video_file.stat().st_mtime,
                'size': video_file.stat().st_size
            }
            video_files.append(video_info)
        
        video_files.sort(key=lambda x: x['timestamp'], reverse=True)
        return jsonify(video_files)
    except Exception as e:
        print(f"Error in API: {e}")
        return jsonify([])

@app.route('/generate-now')
def generate_now():
    """Manually trigger recap generation"""
    try:
        # Run in background thread to avoid blocking
        generation_thread = threading.Thread(target=recap_generator.generate_recap)
        generation_thread.start()
        return jsonify({"status": "Generation started"})
    except Exception as e:
        return jsonify({"error": str(e)})

if __name__ == '__main__':
    # Run initial generation on startup
    if OPENAI_API_KEY and JSON2VIDEO_API_KEY:
        print("Starting AI Movie Recap System...")
        print("Scheduler running - generating recaps every hour")
        app.run(debug=False, host='0.0.0.0', port=int(os.environ.get('PORT', 5000)))
    else:
        print("Please set OPENAI_API_KEY and JSON2VIDEO_API_KEY environment variables")
        app.run(debug=True, host='0.0.0.0', port=5000)